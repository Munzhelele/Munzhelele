
public class Queue<T> implements IQueue<T> {
	private DList<T> queue;
	private int size; 
	private DList<T> front;
	
	/**
	 * The default constructor
	 */
	public Queue() {
		this.queue = new DList<>();
		this.size = 0; 
		this.front= null;
	}
	
	//3 marks
	/* (non-Javadoc)
	 * @see IQueue#enqueue(java.lang.Object)
	 */
	@Override
	public void enqueue(T m) {
		//TODO: Complete  
		queue.addLast(m);
		// size increases 
		size++; 
		
	}
	
	//4 marks
	/* (non-Javadoc)
	 * @see IQueue#dequeue()
	 */
	@Override
	public T dequeue() throws QueueEmptyException {
		//TODO: Complete 
		if(isEmpty()) {
			throw new QueueEmptyException("Queue is empty");
		}
		Node<T> removedNode = queue.front(); // Get the first node in the queue
        T removedItem = removedNode.getElement(); // Get the item stored in the node
        queue.remove(removedNode); // Remove the first item
        size--;
        return removedItem;
	}

	//3 marks
	/* (non-Javadoc)
	 * @see IQueue#front()
	 */
	@Override
	public T front() throws QueueEmptyException {
		//TODO: Complete 
		if (isEmpty()) {
            throw new QueueEmptyException("Queue is empty");
        }
        Node<T> frontNode = queue.front(); // Get the first node in the queue
        return frontNode.getElement(); // Get the data stored in the node
	}

	/* (non-Javadoc)
	 * @see IQueue#size()
	 */
	@Override
	public int size() {
		return size;
	}

	/* (non-Javadoc)
	 * @see IQueue#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}
}
