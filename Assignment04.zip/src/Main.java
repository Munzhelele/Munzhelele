import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
	//15marks
	/**
	 * A function that allocates developers using a developer array and times how long it took to complete
	 * @param A queue of bugs to complete
	 * @param A Queue of Developers
	 * @throws QueueEmptyException 
	 */
	public static void allocateDevsRandomly(Queue<BugFix> bugs, Developer[] devs) throws QueueEmptyException {
        long startTime = System.currentTimeMillis(); // Record start time
        Random random = new Random();

        while (!bugs.isEmpty()) {
            BugFix bug = bugs.dequeue(); // Dequeue a bug fix
            int randomIndex = random.nextInt(devs.length); // Generate a random index
            Developer developer = devs[randomIndex]; // Select a random developer
            int energyConsumption = Math.min(developer.getWorkRate(), bug.getWorkTotal()); // Calculate energy consumption
            developer.setEnergy(developer.getEnergy() - energyConsumption); // Deduct energy
            bug.setWorkTotal(bug.getWorkTotal() - energyConsumption); // Deduct work from bug fix
            if (bug.getWorkTotal() <= 0) {
                System.out.println(bug.getName() + " completed by " + developer.getName());
            } else {
                bugs.enqueue(bug); // Re-enqueue the bug fix if not completed
            }
        }

        long endTime = System.currentTimeMillis(); // Record end time
        long elapsedTime = endTime - startTime; // Calculate elapsed time
        System.out.println("Allocation by Random: ");
        System.out.println("All BugFixes completed in " + elapsedTime + " milliseconds");
    }
    // 15 marks
    /**
     * A function that allocates developers using a queue and times how long it took to complete
     * @param bugs A queue of bugs to complete
     * @param devs A Queue of Developers
     * @throws QueueEmptyException 
     */
	public static void allocateDevsWithQueue(Queue<BugFix> bugs, Queue<Developer> devs) throws QueueEmptyException {
        long startTime = System.currentTimeMillis(); // Record start time

        while (!bugs.isEmpty()) {
            BugFix bug = bugs.dequeue(); // Dequeue a bug fix
            Developer developer = devs.dequeue(); // Dequeue a developer
            int energyConsumption = Math.min(developer.getWorkRate(), bug.getWorkTotal()); // Calculate energy consumption
            developer.setEnergy(developer.getEnergy() - energyConsumption); // Deduct energy
            bug.setWorkTotal(bug.getWorkTotal() - energyConsumption); // Deduct work from bug fix
            if (bug.getWorkTotal() <= 0) {
                System.out.println(bug.getName() + " completed by " + developer.getName());
            } else {
                bugs.enqueue(bug); // Re-enqueue the bug fix if not completed
            }
            devs.enqueue(developer); // Enqueue the developer back to the end of the queue
        }

        long endTime = System.currentTimeMillis(); // Record end time
        long elapsedTime = endTime - startTime; // Calculate elapsed time
        System.out.println("Allocation by Queue: ");
        System.out.println("All BugFixes completed in " + elapsedTime + " milliseconds");
    }
    /** 
     * Execution: 10 marks
     * @param args
     * @throws QueueEmptyException 
     */
	public static void main(String[] args) throws QueueEmptyException {
        Queue<BugFix> bugs = new Queue<BugFix>();        
        Developer[] devs = new Developer[10]; 
        Queue<Developer> devQ = new Queue<Developer>();

        for(int i = 0; i < 10; i++) {
            devs[i] = new Developer(); // Assuming Developer constructor accepts name and workRate
            System.out.println(devs[i]);
            devQ.enqueue(devs[i]);
        }

        for(int j = 0; j < 10; j++) {
            BugFix task = new BugFix(); // Assuming BugFix constructor accepts name and work
            System.out.println(task);
            bugs.enqueue(task);
        }

        // Comment out or make copy
        allocateDevsRandomly(bugs, devs);
        allocateDevsWithQueue(bugs, devQ);    
    }

    // Helper method to generate random work rate for developers
    private static int getRandomWorkRate() {
        return ThreadLocalRandom.current().nextInt(5, 20); // Assuming work rate range between 5 and 20
    }

    // Helper method to generate random work for bug fixes
    private static int getRandomWork() {
        return ThreadLocalRandom.current().nextInt(1, 100); // Assuming work range between 1 and 100
    }
}
